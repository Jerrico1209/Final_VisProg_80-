﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class FrmAdmin : Form
    {
        public FrmAdmin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmMH form9 = new FrmMH();
            form9.Show();
            this.Hide();
        }

        private void BtnInsertKepas_Click(object sender, EventArgs e)
        {
            FrmKepas kepas = new FrmKepas();
            kepas.Show();
            this.Hide();

        }

        private void BtnInsertMonitor_Click_1(object sender, EventArgs e)
        {
            FrmMonitor monitor = new FrmMonitor();
            monitor.Show();
            this.Hide();
        }

        private void BtnSetelan_Click(object sender, EventArgs e)
        {
            FrmSetting setting = new FrmSetting();
            setting.Show();
            this.Hide();
        }

        private void FrmAdmin_Load(object sender, EventArgs e)
        {

        }

        private void BtnInsertMahasiswa_Click(object sender, EventArgs e)
        {
            FrmMH frmMH = new FrmMH();
            frmMH.Show();
            this.Hide();
        }

        private void BtnSetelan_Click_1(object sender, EventArgs e)
        {
            FrmSetting frmSetting = new FrmSetting();
            frmSetting.Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Hide();

            MessageBox.Show("you've been logged out");
        }
    }
}

﻿
namespace FinalProject
{
    partial class MENU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnSeatting = new System.Windows.Forms.Button();
            this.BtnHome = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.BtnDaftar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnSeatting
            // 
            this.BtnSeatting.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BtnSeatting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSeatting.Location = new System.Drawing.Point(37, 190);
            this.BtnSeatting.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnSeatting.Name = "BtnSeatting";
            this.BtnSeatting.Size = new System.Drawing.Size(228, 142);
            this.BtnSeatting.TabIndex = 9;
            this.BtnSeatting.Text = "SEATING IBADAH";
            this.BtnSeatting.UseVisualStyleBackColor = false;
            this.BtnSeatting.Click += new System.EventHandler(this.BtnSeatting_Click_1);
            // 
            // BtnHome
            // 
            this.BtnHome.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BtnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHome.Location = new System.Drawing.Point(37, 329);
            this.BtnHome.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnHome.Name = "BtnHome";
            this.BtnHome.Size = new System.Drawing.Size(228, 142);
            this.BtnHome.TabIndex = 8;
            this.BtnHome.Text = "HOME";
            this.BtnHome.UseVisualStyleBackColor = false;
            this.BtnHome.Click += new System.EventHandler(this.BtnHome_Click_1);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(37, 51);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(228, 142);
            this.button3.TabIndex = 7;
            this.button3.Text = "INPUT POIN";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(793, 561);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 48);
            this.button2.TabIndex = 6;
            this.button2.Text = "Log Out";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // BtnDaftar
            // 
            this.BtnDaftar.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BtnDaftar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDaftar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnDaftar.Location = new System.Drawing.Point(37, 467);
            this.BtnDaftar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnDaftar.Name = "BtnDaftar";
            this.BtnDaftar.Size = new System.Drawing.Size(228, 142);
            this.BtnDaftar.TabIndex = 5;
            this.BtnDaftar.Text = "DAFTAR MAHASISWA";
            this.BtnDaftar.UseVisualStyleBackColor = false;
            this.BtnDaftar.Click += new System.EventHandler(this.BtnDaftar_Click_1);
            // 
            // MENU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 660);
            this.Controls.Add(this.BtnSeatting);
            this.Controls.Add(this.BtnHome);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.BtnDaftar);
            this.Name = "MENU";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MENU";
            this.Load += new System.EventHandler(this.MENU_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnSeatting;
        private System.Windows.Forms.Button BtnHome;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button BtnDaftar;
    }
}
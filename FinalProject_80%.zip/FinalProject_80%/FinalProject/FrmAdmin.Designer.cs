﻿
namespace FinalProject
{
    partial class FrmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnSetelan = new System.Windows.Forms.Button();
            this.BtnInsertMonitor = new System.Windows.Forms.Button();
            this.BtnInsertKepas = new System.Windows.Forms.Button();
            this.BtnInsertMahasiswa = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnSetelan
            // 
            this.BtnSetelan.Location = new System.Drawing.Point(511, 354);
            this.BtnSetelan.Name = "BtnSetelan";
            this.BtnSetelan.Size = new System.Drawing.Size(322, 172);
            this.BtnSetelan.TabIndex = 7;
            this.BtnSetelan.Text = "Setelan";
            this.BtnSetelan.UseVisualStyleBackColor = true;
            this.BtnSetelan.Click += new System.EventHandler(this.BtnSetelan_Click_1);
            // 
            // BtnInsertMonitor
            // 
            this.BtnInsertMonitor.Location = new System.Drawing.Point(100, 354);
            this.BtnInsertMonitor.Name = "BtnInsertMonitor";
            this.BtnInsertMonitor.Size = new System.Drawing.Size(304, 172);
            this.BtnInsertMonitor.TabIndex = 6;
            this.BtnInsertMonitor.Text = "Insert Nama Monitor";
            this.BtnInsertMonitor.UseVisualStyleBackColor = true;
            this.BtnInsertMonitor.Click += new System.EventHandler(this.BtnInsertMonitor_Click_1);
            // 
            // BtnInsertKepas
            // 
            this.BtnInsertKepas.Location = new System.Drawing.Point(511, 126);
            this.BtnInsertKepas.Name = "BtnInsertKepas";
            this.BtnInsertKepas.Size = new System.Drawing.Size(322, 175);
            this.BtnInsertKepas.TabIndex = 5;
            this.BtnInsertKepas.Text = "Insert Nama Kepas";
            this.BtnInsertKepas.UseVisualStyleBackColor = true;
            this.BtnInsertKepas.Click += new System.EventHandler(this.BtnInsertKepas_Click);
            // 
            // BtnInsertMahasiswa
            // 
            this.BtnInsertMahasiswa.Location = new System.Drawing.Point(100, 126);
            this.BtnInsertMahasiswa.Name = "BtnInsertMahasiswa";
            this.BtnInsertMahasiswa.Size = new System.Drawing.Size(304, 175);
            this.BtnInsertMahasiswa.TabIndex = 4;
            this.BtnInsertMahasiswa.Text = "Insert Nama Mahasiswa";
            this.BtnInsertMahasiswa.UseVisualStyleBackColor = true;
            this.BtnInsertMahasiswa.Click += new System.EventHandler(this.BtnInsertMahasiswa_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(390, 569);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 43);
            this.button1.TabIndex = 8;
            this.button1.Text = "Log Out";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // FrmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 653);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BtnSetelan);
            this.Controls.Add(this.BtnInsertMonitor);
            this.Controls.Add(this.BtnInsertKepas);
            this.Controls.Add(this.BtnInsertMahasiswa);
            this.Name = "FrmAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmAdmin";
            this.Load += new System.EventHandler(this.FrmAdmin_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnSetelan;
        private System.Windows.Forms.Button BtnInsertMonitor;
        private System.Windows.Forms.Button BtnInsertKepas;
        private System.Windows.Forms.Button BtnInsertMahasiswa;
        private System.Windows.Forms.Button button1;
    }
}